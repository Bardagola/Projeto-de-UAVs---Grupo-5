clc
clear all
initPlots

%% 1.1

% Parametros

g = 9.807; %aceleração da gravidade
C_D = 2.05; %coeficiente de drag
rho = 1.2922; %densidade do ar

m = 0.027; %massa do drone
x = 0.065; %comprimento
y = 0.065; %largura
z = 0.029; %altura

l = 0.046; %comprimento de cada braço

%Matriz D
Ax = y * z;
Az = x * y;
Ay = x * z;

Drag = 0.5 * C_D * rho * diag([Ax, Ay, Az]);

T1 = 0.3*m*g;
T2 = 0.3*m*g;
T3 = 0.3*m*g;
T4 = 0.3*m*g;
T = T1+T2+T3+T4;

phi = 0;
theta = deg2rad(5);
psi = 0;
u = [T,phi,theta,psi];

Dt = 0.01;
t = 0:Dt:60;
Nsim = length(t);
x = zeros(6,1);

R = [cos(theta)*cos(psi) sin(phi)*sin(theta)*cos(psi)-sin(psi)*cos(phi) cos(phi)*sin(theta)*cos(psi)+sin(psi)*sin(phi)
    cos(theta)*sin(psi) sin(phi)*sin(theta)*sin(psi)+cos(psi)*cos(phi) cos(phi)*sin(theta)*sin(psi)-cos(psi)*sin(phi)
    -sin(theta) sin(phi)*cos(theta) cos(phi)*cos(theta)];

f_g = -m*g*R.'*[0;0;1];
f_p = u(1)*[0;0;1];

for k = 1:Nsim
        
    p = x(1:3,k);
    v = x(4:6,k);
    f_a = -R*Drag*R.'*v;
    p_dot = R*v;
    v_dot = 1/m*(f_g+f_p+f_a); 
  
    x_dot=[p_dot;v_dot];
    
    if k<Nsim
        x(:,k+1)=x(:,k)+Dt*x_dot;
    end   

end

figure(1);
subplot(2,1,1)
plot(t,x(1,:),t,x(2,:),t,x(3,:));
grid on;
legend('$$p_x$$','$$p_y$$','$$p_z$$');
ylabel('$$p[m]$$')
subplot(2,1,2)
plot(t,x(4,:),t,x(5,:),t,x(6,:));
grid on;
legend('$$v_x$$','$$v_y$$','$$v_z$$');
ylabel('$$v[m/s]$$')
xlabel('$$t[s]$$')

%% 1.3

x = zeros(6,1);
u = [T,0,0,0]';
f_g = -m*g*[0;0;1];
f_p = u(1)*Euler2R(u(2:4))*[0;0;1];
A = [zeros(3) eye(3)
    zeros(3) -Drag];
B = [zeros(3);eye(3)];
xLin = zeros(6,1);

for k = 1:Nsim-1
        
    p(:,k) = x(1:3,k);
    v(:,k) = x(4:6,k);
    f_a(:,k) = -Drag*v(:,k);
    p_dot = v(:,k);
    v_dot = 1/m*(f_g+f_p+f_a(:,k));
    
    x_dot=[p_dot;v_dot];
    ua = v_dot;
    x(:,k+1)=x(:,k)+Dt*x_dot;
    
    xLin_dot=A*xLin(:,k)+B*ua; 
    xLin(:,k+1) = xLin(:,k)+Dt*xLin_dot;

end

figure(2);
subplot(2,1,1)
plot(t,xLin(1,:),t,xLin(2,:),t,xLin(3,:));
grid on;
legend('$$p_x$$','$$p_y$$','$$p_z$$');
ylabel('$$p[m]$$')
subplot(2,1,2)
plot(t,xLin(4,:),t,xLin(5,:),t,xLin(6,:));
grid on;
legend('$$v_x$$','$$v_y$$','$$v_z$$');
ylabel('$$v[m/s]$$')
xlabel('$$t[s]$$')


%% 1.4

Q = 100*eye(6);
R = eye(3);

K = lqr(A,B,Q,R);
x(:,1) = [5,5,5,0,0,0];
xLin(:,1) = x(:,1);

for k = 1:Nsim-1
        
    p(:,k) = x(1:3,k);
    v(:,k) = x(4:6,k);
    f_a(:,k) = -Drag*v(:,k);
    p_dot = v(:,k);
    v_dot = 1/m*(f_g+f_p+f_a(:,k));
    
    x_dot=[p_dot;v_dot];
    ua = v_dot;
    x(:,k+1)=x(:,k)+Dt*x_dot;
    
    xLin_dot=(A-B*K)*xLin(:,k); 
    xLin(:,k+1) = xLin(:,k)+Dt*xLin_dot;

end

figure(3);
subplot(3,2,1)
plot(t,xLin(1,:));
grid on;
legend('$$p_x$$');
ylabel('$$p_x[m]$$')
subplot(3,2,3)
plot(t,xLin(2,:));
legend('$$p_y$$');
ylabel('$$p_y[m]$$')
grid on;
subplot(3,2,5)
plot(t,xLin(3,:));
legend('$$p_z$$');
ylabel('$$p_z[m]$$')
grid on;
xlabel('$$t[s]$$')
subplot(3,2,2)
plot(t,xLin(4,:));
grid on;
legend('$$v_x$$');
ylabel('$$v_x[m/s]$$')
subplot(3,2,4)
plot(t,xLin(5,:));
legend('$$v_y$$');
ylabel('$$v_y[m/s]$$')
grid on;
subplot(3,2,6)
plot(t,xLin(6,:));
legend('$$v_z$$');
ylabel('$$v_z[m/s]$$')
grid on;
xlabel('$$t[s]$$')

%% 1.5 e 1.6

p_d = [1;1;1]*(3*(t>10)-2*(t>30))-[0;0;1]*(t>40);
v_d = zeros(3,Nsim);
% p_d = [(sin(t)+1).*(t>5);(t>5);(t>5)];
    


x(:,1) = [0,0,0,0,0,0];
xLin(:,1) = x(:,1);
ud = f_g;

for k = 1:Nsim-1
        
    % p(:,k) = x(1:3,k);
    % v(:,k) = x(4:6,k);
    % f_a(:,k) = -Drag*v(:,k);
    % p_dot = v(:,k);
    % v_dot = 1/m*(f_g+f_p+f_a(:,k));
    % x_dot = [p_dot;v_dot];
    % x(:,k+1)=x(:,k)+Dt*x_dot;
    % 
    % ep(:,k) = p(:,k)-p_d(:,k);
    % ev(:,k) = v(:,k)-v_d(:,k);
    % ep_dot = ev(:,k);
    % ev_dot = v_dot-ud;
    % 
    % ex_dot = [ep_dot;ev_dot];
    % ua = v_dot;

    % x(:,k+1) = x(:,k)+Dt*x_dot;

    exLin(:,k) = (xLin(:,k)-[p_d(:,k);v_d(:,k)]);
    ul(:,k) = ud-K*exLin(:,k); %u~+ud=u
    xLin_dot = A*xLin(:,k)+B*ul(:,k); 
    xLin(:,k+1) = xLin(:,k)+Dt*xLin_dot;

end

figure(4);
subplot(3,2,1)
plot(t,xLin(1,:),t,p_d(1,:));
grid on;
legend('$$p_x$$','$$ref_x$$');
ylabel('$$p_x[m]$$')
subplot(3,2,3)
plot(t,xLin(2,:),t,p_d(2,:));
legend('$$p_y$$','$$ref_y$$');
ylabel('$$p_y[m]$$')
grid on;
subplot(3,2,5)
plot(t,xLin(3,:),t,p_d(3,:));
legend('$$p_z$$','$$ref_z$$');
ylabel('$$p_z[m]$$')
grid on;
xlabel('$$t[s]$$')
subplot(3,2,2)
plot(t,xLin(4,:));
grid on;
legend('$$v_x$$');
ylabel('$$v_x[m/s]$$')
subplot(3,2,4)
plot(t,xLin(5,:));
legend('$$v_y$$');
ylabel('$$v_y[m/s]$$')
grid on;
subplot(3,2,6)
plot(t,xLin(6,:));
legend('$$v_z$$');
ylabel('$$v_z[m/s]$$')
grid on;
xlabel('$$t[s]$$')

