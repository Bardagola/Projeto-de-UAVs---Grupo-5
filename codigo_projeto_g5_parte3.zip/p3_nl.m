clc
clear all
initPlots

%%

% Parametros

g = 9.807; %aceleração da gravidade
C_D = 2.05; %coeficiente de drag
rho = 1.2922; %densidade do ar

m = 0.027; %massa do drone
x = 0.065; %comprimento
y = 0.065; %largura
z = 0.029; %altura

l = 0.046; %comprimento de cada braço

%Matriz D
Ax = y * z;
Az = x * y;
Ay = x * z;

Drag = 0.5 * C_D * rho * diag([Ax, Ay, Az]);

T1 = 0.3*m*g;
T2 = 0.3*m*g;
T3 = 0.3*m*g;
T4 = 0.3*m*g;
T = T1+T2+T3+T4;

phi = 0;
theta = deg2rad(5);
psi = 0;
u = [T,phi,theta,psi];

Dt = 0.01;
Tend = 60;
t = 0:Dt:Tend;
Nsim = length(t);
x = zeros(6,1);

R = [cos(theta)*cos(psi) sin(phi)*sin(theta)*cos(psi)-sin(psi)*cos(phi) cos(phi)*sin(theta)*cos(psi)+sin(psi)*sin(phi)
    cos(theta)*sin(psi) sin(phi)*sin(theta)*sin(psi)+cos(psi)*cos(phi) cos(phi)*sin(theta)*sin(psi)-cos(psi)*sin(phi)
    -sin(theta) sin(phi)*cos(theta) cos(phi)*cos(theta)];

f_g = -m*g*R.'*[0;0;1];
f_p = u(1)*[0;0;1];

for k = 1:Nsim
        
    p = x(1:3,k);
    v = x(4:6,k);
    f_a = -R*Drag*R.'*v;
    p_dot = R*v;
    v_dot = 1/m*(f_g+f_p+f_a); 
  
    x_dot=[p_dot;v_dot];
    
    if k<Nsim
        x(:,k+1)=x(:,k)+Dt*x_dot;
    end   

   
end

figure(1);
subplot(2,1,1)
plot(t,x(1,:),t,x(2,:),t,x(3,:));
grid on;
legend('$$p_x$$','$$p_y$$','$$p_z$$');
ylabel('$$p[m]$$')
subplot(2,1,2)
plot(t,x(4,:),t,x(5,:),t,x(6,:));
grid on;
legend('$$v_x$$','$$v_y$$','$$v_z$$');
ylabel('$$v[m/s]$$')
xlabel('$$t[s]$$')

%% Controlo

p0 = [0;0;0];
v0 = [0;0;0];
nx = 6;
x = zeros(nx,Nsim);
T = zeros(1,Nsim);
lbd = zeros(3,Nsim);
x(:,1) = [p0;v0];
p_ref_static = [1;1;1];

p_ref = [ zeros(3,20/Dt+1), p_ref_static*ones(1,(Tend-20)/Dt)];
v_ref = zeros(3,Nsim);
a_ref = zeros(3,Nsim);

kp = 0.3;
kv = 0.2;
zW = [0;0;1];

for k=1:Nsim

    p = x(1:3,k);
    v = x(4:6,k);
    p_d = p_ref(:,k);
    v_d = v_ref(:,k);
    a_d = a_ref(:,k);
    
    e_p = p - p_d;
    e_v = v - v_d;

    f_des = -kp*e_p-kv*e_v+m*g*zW+m*a_d;

    zB_des(:,k) = f_des/norm(f_des);
    T(:,k) = f_des'*zB_des(:,k);
    T(:,k) = max(0,min(0.35,T(:,k)));

    p_dot = v;
    v_dot = 1/m*(-m*g*zW+T(:,k)*zB_des(:,k)-Drag*v); 
  
    x_dot=[p_dot;v_dot];
    
    if k<Nsim
        x(:,k+1)=x(:,k)+Dt*x_dot;
    end

end

figure(2);
subplot(3,2,1)
plot(t,x(1,:),t,p_ref(1,:));
grid on;
legend('$$p_x$$','$$ref_{p_x}$$');
ylabel('$$p_x[m]$$')
subplot(3,2,3)
plot(t,x(2,:),t,p_ref(2,:));
legend('$$p_y$$','$$ref_{p_y}$$');
ylabel('$$p_y[m]$$')
grid on;
subplot(3,2,5)
plot(t,x(3,:),t,p_ref(3,:));
legend('$$p_z$$','$$ref_{p_z}$$');
ylabel('$$p_z[m]$$')
grid on;
xlabel('$$t[s]$$')
subplot(3,2,2)
plot(t,x(4,:),t,v_ref(1,:));
grid on;
legend('$$v_x$$','$$ref_{v_x}$$');
ylabel('$$v_x[m/s]$$')
subplot(3,2,4)
plot(t,x(5,:),t,v_ref(2,:));
legend('$$v_y$$','$$ref_{v_y}$$');
ylabel('$$v_y[m/s]$$')
grid on;
subplot(3,2,6)
plot(t,x(6,:),t,v_ref(3,:));
legend('$$v_z$$','$$ref_{v_z}$$');
ylabel('$$v_z[m/s]$$')
grid on;
xlabel('$$t[s]$$')

figure(3)
subplot(3,1,1)
plot(t,T);
grid on;
legend('$$T$$');
ylabel('$$T [N]$$')
subplot(3,1,2)
plot(t,zB_des(1,:));
legend('$$\theta$$');
ylabel('$$\theta [rad]$$')
grid on;
subplot(3,1,3)
plot(t,-zB_des(2,:));
legend('$$\phi$$');
ylabel('$$\phi [rad]$$')
grid on;
xlabel('$$t[s]$$')

%% Animação

set(0,'defaultTextInterpreter','latex');
set(0,'defaultLegendInterpreter','latex');
sstblue         = [0,128,255]/255;
sstlightblue    = [48,208,216]/255;
sstlighterblue  = [50,220,240]/255;
sstlightestblue = [60,230,255]/255;
sstgreen        = [43,191,92]/255;
sstlightgreen   = [140,255,200]/255;
sstlightergreen = [160,255,225]/255;
sstgray         = [70,70,70]/255;
sstlightgray    = [200,200,200]/255;

dcolors = { sstgreen, sstblue, sstlightblue, sstlighterblue, sstlightestblue, sstlightgreen, sstlightergreen, sstlightgray };

figure(104);
hini = plot3(x(1,1),x(2,1),x(3,1),'o','Color',dcolors{1},'MarkerSize',2);
hold on
href = plot3(p_ref(1,:),p_ref(2,:),p_ref(3,:),'--','Color',sstgray);
hp = plot3(x(1,1:2),x(2,1:2),x(3,1:2),'-','Color',dcolors{1});
hd = drone_plot(x(1:3,1),[-zB_des(2,:);zB_des(1,:);zeros(1,Nsim)],[],dcolors{1});
hold off;
grid on;
axis equal;
axis([-1.2 1.2 -1.2 1.2 0 3]);
xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
legend('start','end','trajectory');

for k = 2:2:Nsim
    
    set(hp,'xdata',x(1,1:k),'ydata',x(2,1:k),'zdata',x(3,1:k));
    drone_plot(x(1:3,k),[-zB_des(2,k);zB_des(1,k);0],hd);
    axis equal;
    drawnow;
    %pause(dt/10);

end