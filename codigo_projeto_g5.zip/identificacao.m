clc

%% Dados

csvfilename = '2024-04-04_log07.csv';
T = readtable(csvfilename);

% get data from table
time = table2array(T(:,1))'*1e-3;
pos = table2array(T(:,2:4))';
vel = table2array(T(:,5:7))';
% acc = table2array(T(:,8:10))';
lbd = table2array(T(:,8:10))'*pi/180;
om = table2array(T(:,11:13))'*pi/180;
pos_ref = table2array(T(:,14:16))';
yaw_ref = table2array(T(:,17))';
motors = table2array(T(:,18:21))';
thrust = sum(motors);

setx = [pos(1,:);vel(1,:);lbd(2,:);om(1,:)]; %px,vx,theta,omegax
sety = [pos(2,:);vel(2,:);lbd(1,:);om(2,:)]; %py,vy,phi,omegay
setz = [pos(3,:);vel(3,:);thrust;om(3,:)]; %pz,vz,thrust,omegaz

figure(1)
subplot(4,1,1)
plot(time,setx(1,:))
xlabel('$$t$$')
ylabel('$$p_x$$')
grid on
subplot(4,1,2)
plot(time,setx(2,:))
xlabel('$$t$$')
ylabel('$$v_x$$')
grid on
subplot(4,1,3)
plot(time,setx(3,:))
xlabel('$$t$$')
ylabel('$$\theta$$')
grid on
subplot(4,1,4)
plot(time,setx(4,:))
xlabel('$$t$$')
ylabel('$$\omega_x$$')
grid on


figure(2)
subplot(4,1,1)
plot(time,sety(1,:))
xlabel('$$t$$')
ylabel('$$p_y$$')
grid on
subplot(4,1,2)
plot(time,sety(2,:))
xlabel('$$t$$')
ylabel('$$v_y$$')
grid on
subplot(4,1,3)
plot(time,sety(3,:))
xlabel('$$t$$')
ylabel('$$\phi$$')
grid on
subplot(4,1,4)
plot(time,sety(4,:))
xlabel('$$t$$')
ylabel('$$\omega_y$$')
grid on

figure(3)
subplot(4,1,1)
plot(time,setz(1,:))
xlabel('$$t$$')
ylabel('$$p_z$$')
grid on
subplot(4,1,2)
plot(time,setz(2,:))
xlabel('$$t$$')
ylabel('$$v_z$$')
grid on
subplot(4,1,3)
plot(time,setz(3,:))
xlabel('$$t$$')
ylabel('$$T$$')
grid on
subplot(4,1,4)
plot(time,setz(4,:))
xlabel('$$t$$')
ylabel('$$\omega_z$$')
grid on

%% Usar tools do matlab

Ts = mean(diff(time));
u_id1 = lbd(2,:)';
y_id1 = pos(1,:)';
u_id2 = lbd(1,:)';
y_id2 = pos(2,:)';
u_id3 = thrust';
y_id3 = pos(3,:)';
r_id1 = pos_ref(1,:)';
r_id2 = pos_ref(2,:)';
r_id3 = pos_ref(3,:)';
