clc
initPlots

%% Modelo

% Parametros

g = 9.807; %aceleração da gravidade
C_D = 2.05; %coeficiente de drag
rho = 1.2922; %densidade do ar

m = 0.027; %massa do drone
x = 0.065; %comprimento
y = 0.065; %largura
z = 0.029; %altura

l = 0.046; %comprimento de cada braço

%Matriz D
Ax = y * z;
Az = x * y;
Ay = x * z;

D = 0.5 * C_D * rho * diag([Ax, Ay, Az]);

%Matriz J
J = [1/12*m*(z^2+y^2) 0 0
     0 1/12*m*(x^2+z^2) 0
     0 0 1/12*m*(y^2+x^2)];
 
%% Forças e momentos

T1 = 0.5*m*g;
T2 = 0.5*m*g;
T3 = 0.5*m*g;
T4 = 0.5*m*g;

f1 = [0;0;T1];
f2 = [0;0;T2];
f3 = [0;0;T3];
f4 = [0;0;T4];

f_p = f1+f2+f3+f4;

p1 = l*[cos(deg2rad(-45));sin(deg2rad(-45));0];
p2 = l*[cos(deg2rad(-135));sin(deg2rad(-135));0];
p3 = l*[cos(deg2rad(135));sin(deg2rad(135));0];
p4 = l*[cos(deg2rad(45));sin(deg2rad(45));0];

np1 = cross(p1,f1)+[0;0;0.0245];
np2 = cross(p2,f2)+[0;0;-0.0245];
np3 = cross(p3,f3)+[0;0;0.0245];
np4 = cross(p4,f4)+[0;0;-0.0245];

np = np1+np2+np3+np4;

%% simulação

Dt = 0.01;
t = 0:Dt:60;
Nsim = length(t);
x = zeros(12,1);
y = zeros(4,Nsim);

for k = 1:Nsim

  p = x(1:3,k);
  v = x(4:6,k);
  lambda = x(7:9,k);
  omega = x(10:12,k);

  phi = lambda(1);
  theta = lambda(2);
  psi = lambda(3);
    
  R = [cos(theta)*cos(psi) sin(phi)*sin(theta)*cos(psi)-sin(psi)*cos(phi) cos(phi)*sin(theta)*cos(psi)+sin(psi)*sin(phi)
        cos(theta)*sin(psi) sin(phi)*sin(theta)*sin(psi)+cos(psi)*cos(phi) cos(phi)*sin(theta)*sin(psi)-cos(psi)*sin(phi)
        -sin(theta) sin(phi)*cos(theta) cos(phi)*cos(theta)];
    
  Q = [1 sin(phi)*tan(theta) cos(phi)*tan(theta)
        0 cos(phi) -sin(phi)
        0 sin(phi)/cos(theta) cos(phi)/cos(theta)];

  f_a = -R*D*R.'*v;

  f_g = -m*g*R.'*[0;0;1]; 

  p_dot = R*v;
  v_dot = -skew(omega)*v + (f_g+f_a+f_p)/m;
  lambda_dot = Q*omega;
  omega_dot = (-J^-1*skew(omega)*J*omega) + J^-1*np;
  
  x_dot=[p_dot;v_dot;lambda_dot;omega_dot];

  x(:,k+1)=x(:,k)+Dt*x_dot;
  y(1,k)=x(1,k); %px
  y(2,k)=x(2,k); %py
  y(3,k)=x(3,k); %pz
  y(4,k)=x(6,k); %vz

end

figure(1);
plot(t,y(1,:),t,y(2,:),t,y(3,:),t,y(4,:));
grid on;
legend('$$p_x$$','$$p_y$$','$$p_z$$','$$v_z$$');
