clc
initPlots

%% Derivadas

syms px py pz vx vy vz phi theta psi omegax omegay omegaz T1 T2 T3 T4

m = 0.027; %massa do drone
g = 9.807; %aceleracao gravitica da Terra
l = 0.046; %comprimento do braco

x = 0.065; %comprimento
y = 0.065; %largura
z = 0.029; %altura

C_D = 2.05; %coeficiente de drag
rho = 1.2922; %densidade do ar

%Matriz D
Ax = y * z;
Az = x * y;
Ay = x * z;

Drag = 0.5 * C_D * rho * diag([Ax, Ay, Az]);


J = [1/12*m*(z^2+y^2) 0 0
     0 1/12*m*(x^2+z^2) 0
     0 0 1/12*m*(y^2+x^2)];

R = [cos(theta)*cos(psi), sin(phi)*sin(theta)*cos(psi)-sin(psi)*cos(phi) , cos(phi)*sin(theta)*cos(psi)+sin(psi)*sin(phi);
    cos(theta)*sin(psi) , sin(phi)*sin(theta)*sin(psi)+cos(psi)*cos(phi) , cos(phi)*sin(theta)*sin(psi)-cos(psi)*sin(phi);
    -sin(theta)         , sin(phi)*cos(theta)                            , cos(phi)*cos(theta)];

Q = [1, sin(phi)*tan(theta), cos(phi)*tan(theta);
    0, cos(phi) ,-sin(phi);
    0, sin(phi)/cos(theta), cos(phi)/cos(theta)];

p = [px ; py ; pz];
v = [vx; vy; vz];
lbd = [phi; theta; psi];
omega = [omegax; omegay; omegaz];

f1 = [0;0;1];
f2 = [0;0;1];
f3 = [0;0;1];
f4 = [0;0;1];

p1 = l*[cos(deg2rad(-45));sin(deg2rad(-45));0];
p2 = l*[cos(deg2rad(-135));sin(deg2rad(-135));0];
p3 = l*[cos(deg2rad(135));sin(deg2rad(135));0];
p4 = l*[cos(deg2rad(45));sin(deg2rad(45));0];


np1 = cross(p1,f1)+[0;0;-0.0245];
np2 = cross(p2,f2)+[0;0;0.0245];
np3 = cross(p3,f3)+[0;0;-0.0245];
np4 = cross(p4,f4)+[0;0;0.0245];

u = [1 1 1 1
    np1 np2 np3 np4];

%Forcas

np = [u(2,:);u(3,:);u(4,:)]*[T1,T2,T3,T4]';
T = u(1,:)*[T1,T2,T3,T4]';
f_p = T*[0;0;1];
f_g = -m*g*R.'*[0;0;1];
f_a = -R*Drag*R.'*v;


p_dot = R*v;
v_dot = -skew(omega)*v + (f_g+f_a+f_p)/m;
lambda_dot = Q*omega;
omega_dot = -J^-1*skew(omega)*J*omega + J^-1*np;

aux1 = [diff(p_dot, phi), diff(p_dot, theta), diff(p_dot, psi)];
aux2 = [diff(v_dot, vx), diff(v_dot, vy), diff(v_dot, vz)];
aux3 = [diff(v_dot, phi), diff(v_dot, theta), diff(v_dot, psi)];
aux4 = [diff(v_dot, omegax), diff(v_dot, omegay), diff(v_dot, omegaz)];
aux5 = [diff(lambda_dot, phi), diff(lambda_dot, theta), diff(lambda_dot, psi)];
aux6 = [diff(omega_dot, omegax), diff(omega_dot, omegay), diff(omega_dot, omegaz)];

%% Linearização

A = [zeros(3), R, aux1, zeros(3)
    zeros(3), aux2, aux3, aux4
    zeros(3), zeros(3), aux5, Q
    zeros(3), zeros(3), zeros(3), aux6];

B=[zeros(3,4)
   1/m*[0;0;1] zeros(3,3)
   zeros(3,4)
   zeros(3,1) J^-1];

C = [eye(9), zeros(9,3)];

D = zeros(9,4);

Dt = 0.01;
t = 0:Dt:60;
Nsim = length(t);

%% Caso 1 - Consideramos omega=[0;0;0] e v=[0;0;0] (hover)

omega_eq1 = [0;0;0];
v_eq1 = [0;0;0];
lbd_eq1 = [0;0;0];

var = [vx,vy,vz,phi,theta,psi,omegax,omegay,omegaz];
val1 = [v_eq1(1),v_eq1(2),v_eq1(3),lbd_eq1(1),lbd_eq1(2),lbd_eq1(3),omega_eq1(1),omega_eq1(2),omega_eq1(3)];

A1 = subs(A,var,val1);
A1 = double(A1);

x01 = [zeros(2,1);1;zeros(9,1)];
u_eq = u*[0.25*m*g,0.25*m*g,0.25*m*g,0.25*m*g]';
sys1 = ss(A1,B,C,D);
ul1 = ones(Nsim,1)*(u*[0.25*m*g,0.25*m*g,0.25*m*g,0.25*m*g]'-u_eq)';
yli1 = lsim(sys1,ul1,t,x01);

figure(1);
plot(t,yli1(:,1),t,yli1(:,2),t,yli1(:,3),t,yli1(:,6));
legend('$$p_x$$','$$p_y$$','$$p_z$$','$$v_z$$')
grid on;

%% Caso 2 - Consideramos omega=[0;0;0] e v=[0;3;0] 

omega_eq2 = [0;0;0];
v_eq2 = [0;3;0];
lbd_eq2 = deg2rad([-20;0;0]); %??

val2 = [v_eq2(1),v_eq2(2),v_eq2(3),lbd_eq2(1),lbd_eq2(2),lbd_eq2(3),omega_eq2(1),omega_eq2(2),omega_eq2(3)];

A2 = subs(A,var,val2);
A2 = double(A2);

sys2 = ss(A2,B,C,D);

x02 = [zeros(2,1);1;v_eq2;lbd_eq2;omega_eq2];
ul2 = ones(Nsim,1)*(u*[0.5*m*g,0.5*m*g,0.5*m*g,0.5*m*g]'-u_eq)';

yli2 = lsim(sys2,ul2,t,x02);

figure(2);
plot(t,yli2(:,1),t,yli2(:,2),t,yli2(:,3),t,yli2(:,5),t,yli2(:,6),t,yli2(:,7));
legend('$$p_x$$','$$p_y$$','$$p_z$$','$$v_y$$','$$v_z$$','$$\phi$$')
grid on

%% Analises

[V1,D1,W1] = eig(A1);
[V2,D2,W2] = eig(A2);
    
disp('modelo 1')
disp('Valores próprios');
disp(D1);
disp('Controlabilidade de cada modo');
cont1 = W1'*B
disp('Observabilidade  de cada modo');
obs1 = C*V1
disp('Matriz de Jordan');
J1 = jordan(A1)

disp('modelo 2')
disp('Valores próprios');
disp(D2);
disp('Controlabilidade de cada modo');
cont2 = W2'*B
disp('Matriz observabilidade de cada modo');
obs2 = C*V2
disp('Matriz de Jordan');
J2 = jordan(A2)

%% Funções de transferência

tf_mod1 = tf(sys1);
tf_mod2 = tf(sys2);

G_mod1 = [tf_mod1(7,2) , tf_mod1(8,3)
            tf_mod1(9,4) , tf_mod1(3,1)
            tf_mod1(2,2) , tf_mod1(1,3)];

G_mod2 = [tf_mod2(7,2) , tf_mod2(8,3)
            tf_mod2(9,4) , tf_mod2(3,1)
            tf_mod2(2,2) , tf_mod2(1,3)];

figure(3)
rlocus(G_mod1(2,2))
title('Modelo 1 - p_z em função de T')
figure(4)
rlocus(G_mod1(3,1))
title('Modelo 1 - p_y em função de n_x')
figure(5)
rlocus(G_mod2(2,2))
title('Modelo 2 - p_z em função de T')
figure(6)
rlocus(G_mod2(3,1))
title('Modelo 2 - p_y em função de n_x')
